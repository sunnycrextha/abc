﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2
{
    /// <summary>
    /// This is a class inheriting the property from shape and getting refrences from main class and 
    /// drawing the circle in the panel
    /// </summary>
    class Circle : Shape // inheriting the property from shape
    {
        

        public void drawdesign(string[] cmd, Graphics h, int k, int l)
        {
            int x = Convert.ToInt32(cmd[1]);
            Pen s = new Pen(Color.Red,4);
           
            DialogResult box = MessageBox.Show("Want To draw", "Circle", MessageBoxButtons.YesNo);
            string transform = box.ToString();
            if (transform == "Yes")
            {
                // p.ScaleTransform(2, 1);
                h.RotateTransform(20.0F);
                h.DrawEllipse(s, k, l, x, x);//drawing the circle on panel

            }
            else
            {
                h.DrawEllipse(s, k, l, x, x);//drawing the circle on panel
            }
            h.DrawEllipse(s, k, l, x, x);//drawing the circle on panel
        }

     
    }
}
