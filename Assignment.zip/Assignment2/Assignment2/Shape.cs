﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// This is actually a interface which helps other shapes to inherit the property of shape
/// for inheritance model and helps programmer to add more shapes in the system
/// </summary>
namespace Assignment2
{
    /// <summary>
    /// making an interface where all shapes can inherit
    /// </summary>
    interface Shape
    {
        void drawdesign(string[] cmd, Graphics h, int k, int l);//making a comman class where all shapes can inherit this property
    }
}
