﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    /// <summary>
    /// This class is actually been made to control all the shapes and shows the implementation of 
    /// factory design pattern 
    /// </summary>
    class ShapeFactory
    {
        /// <summary>
        /// This is the heart method of this whole program which help to call the shapes
        /// and return the shape object in main class
        /// </summary>
        /// <param name="shapeType">it takes the shape name as parameter</param>
        /// <returns>and sends the shape named class as refrences</returns>
        public Shape getShape(String shapeType)//taking shape type name
        {
            if (shapeType == null)
            {
                return null;//returning if null if value is nothing 
            }
            if (shapeType=="circle")
            {
                return new Circle();//returning the circle class reference if the value is circle

            }
            else if (shapeType=="rectangle")
            {
                return new Rectangle();//returning the rectangle class refrences if the value is rectangle

            }
            else if (shapeType=="triangle")
            {
                return new Triangle();//returning the triangle class references if the value is triangle
            }
            else if (shapeType == "polygon")
            {
                return new Polygon();//returning the triangle class references if the value is triangle
            }
            return null;
        }
    }
}
