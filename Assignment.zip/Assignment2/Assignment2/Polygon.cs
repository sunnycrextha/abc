﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Assignment2
{
    class Polygon : Shape
    {
        public void drawdesign(string[] cmd, Graphics h, int k, int l)
        {
            MessageBox.Show("Hey you are great");


            int bas = Convert.ToInt32(cmd[1]);
            int adj = Convert.ToInt32(cmd[2]);
            int ht = Convert.ToInt32(cmd[3]);
            int bas2 = Convert.ToInt32(cmd[4]);
            int adj2 = Convert.ToInt32(cmd[5]);
            int ht2 = Convert.ToInt32(cmd[6]);
            int ht4 = Convert.ToInt32(cmd[7]);
            Pen sb = new Pen(Color.Red, 4);
            Point[] pok = { new Point(k, bas), new Point(k+5, adj), new Point(k+10, ht),
            new Point(k+20, bas2), new Point(k+30, adj2), new Point(k+35, ht2),new Point(k+25, ht4)};
            h.DrawPolygon(sb, pok);//drawing the Polygon on the panel 
        }
    }
}
