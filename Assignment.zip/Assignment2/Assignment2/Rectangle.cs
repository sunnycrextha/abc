﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    /// <summary>
    /// This is a class inheriting the property from shape and getting refrences from main class and 
    /// drawing the rectangle in the panel
    /// </summary>
    class Rectangle : Shape//inheting the property from shape
    {
        public void drawdesign(string[] cmd, Graphics h, int k, int l)
        {
            int x = Convert.ToInt32(cmd[1]);
            int y = Convert.ToInt32(cmd[2]);
            Pen sbk = new Pen(Color.Red,4);
            h.DrawRectangle(sbk, k, l, x, y);//drawing the rectangle in panel
        }
    }
}
