﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Assignment2
{
    /// <summary>
    /// This is a class inheriting the property from shape and getting refrences from main class and 
    /// drawing the triangle in the panel
    /// </summary>
    class Triangle : Shape //inheriting the property from shape
    {
        public void drawdesign(string[] cmd, Graphics h, int k, int l)
        {
            int bas = Convert.ToInt32(cmd[1]);
            int adj = Convert.ToInt32(cmd[2]);
            int ht = Convert.ToInt32(cmd[3]);
            Pen sb = new Pen(Color.Red,4);
            Point[] pok = { new Point(k, bas), new Point(k, adj), new Point(l+ht, ht)};
            h.DrawPolygon(sb, pok);//drawing the triangle on the panel

        }
    }
}
