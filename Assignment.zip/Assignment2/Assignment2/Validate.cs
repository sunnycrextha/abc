﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Assignment2
{
    /// <summary>
    /// This is a Command Parser Class which help us to get know if the command is correct or not
    /// </summary>
   public class Validate
    {


        /// <summary>
        /// This is  actually a method which we call to validate the commands
        /// </summary>
        /// <param name="a">here we send the commands from textbox1 as parameter</param>
        /// <returns>this return the commands segragating them or return 0,1 if command have format 
        /// exception or command is not matched</returns>

        public string[] RetValue(string a)
        {
            string[] result = a.Split(',', ' ');//splitting the value
            string[] ret = { };//this will return the value
            int k = 0;
            int l = 0;
            int z = 0;
            try
            {
                if (result[1].GetType() == typeof(string))
                {
                    if (Form1.Integer.ContainsKey(result[1]) == true)
                    {
                        k = Form1.Integer[result[1]];
                    }
                }

                if (result[2].GetType() == typeof(string))
                {
                    if (Form1.Integer.ContainsKey(result[2]))
                    {
                        l = Form1.Integer[result[2]];
                    }
                }
                

                if (result[3].GetType() == typeof(string))
                {
                    if (Form1.Integer.ContainsKey(result[3]))
                    {
                        z = Form1.Integer[result[3]];
                    }
                }
      
            }
            catch(IndexOutOfRangeException kj)
            {}
            catch (FormatException e)//catching format type exception
            {
                string[] rest = { "0", "0" };
                ret = rest;
            }




            try
                {

                if (result[0].ToUpper() == "MOVETO")//checking move to commands
                {

                    if (result.Length < 4)//checking the length of commands
                    {

                        string first = Convert.ToString(k);
                        string second = Convert.ToString(l);
                        string[] retu = { "moveTo", first, second };
                        ret = retu;//returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the Default value if its wrong

                    }

                }
                else if (result[0].ToUpper() == "DRAWTO")//checking Draw to command
                {

                    if (result.Length < 4)//checking the length of command
                    {
                        
                        string first = Convert.ToString(k);
                        string second = Convert.ToString(l);
                        string[] retu = { "drawTo", first, second };
                        ret = retu;//returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;// returning the default value if its wrong

                    }
                }
                else if (result[0].ToUpper() == "CIRCLE")//checking the circle command
                {
                    if (result.Length < 3)//checking the length of command
                    {
                        
                        string first = Convert.ToString(k);
                        string[] retu = { "circle", first };
                        ret = retu;//Returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the default value if its wrong

                    }
                }
                else if (result[0].ToUpper() == "RECTANGLE")//checking the rectangle command
                {
                    if (result.Length < 4)//checking the length on command
                    {
                        
                        string first = Convert.ToString(k);
                        string second = Convert.ToString(l);
                        string[] retu = { "rectangle", first, second };
                        ret = retu;//returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the default value if its wrong

                    }
                }
                else if (result[0].ToUpper() == "POLYGON")//cheking the triangle command
                {
                    if (result.Length < 9)//cheking the length of command
                    {
                        int bas = Convert.ToInt32(result[1]);
                        int adj = Convert.ToInt32(result[2]);
                        int ht = Convert.ToInt32(result[3]);
                        int bas2 = Convert.ToInt32(result[4]);
                        int adj2 = Convert.ToInt32(result[5]);
                        int ht2 = Convert.ToInt32(result[6]);
                        int ht4 = Convert.ToInt32(result[7]);
                        string first = Convert.ToString(bas);
                        string second = Convert.ToString(adj);
                        string third = Convert.ToString(ht);
                        string fourth = Convert.ToString(bas2);
                        string fifth = Convert.ToString(adj2);
                        string sixth = Convert.ToString(ht2);
                        string seventh = Convert.ToString(ht4);
                        string[] retu = { "polygon", first, second, third, fourth, fifth, sixth, seventh };
                        ret = retu;//returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the value if its wrong

                    }
                }
                else if (result[0].ToUpper() == "TRIANGLE")//cheking the triangle command
                {
                    if (result.Length < 5)//cheking the length of command
                    {
                        
                        string first = Convert.ToString(k);
                        string second = Convert.ToString(l);
                        string third = Convert.ToString(z);
                        string[] retu = { "triangle", first, second, third };
                        ret = retu;//returning the value

                    }
                    else
                    {
                        MessageBox.Show("One command at a time");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the value if its wrong

                    }
                }

                else if (result[1] == "=")
                {
                    if (result.Length < 4)
                    {
                        int bast = Convert.ToInt32(result[2]);
                        string first = Convert.ToString(bast);
                        string[] retu = { "=", result[0], first };
                        ret = retu;
                    }
                    else
                    {
                        MessageBox.Show("A Variable can contain just a value");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the value if its wrong
                    }
                }
                else if (result[1] == "+")
                {
                    if (result.Length < 4)
                    {
                        int bast = Convert.ToInt32(result[2]);
                        string first = Convert.ToString(bast);
                        string[] retu = { "+", result[0], first };
                        ret = retu;
                    }
                    else
                    {
                        MessageBox.Show("A Variable can contain just a value");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the value if its wrong
                    }
                }
                else if (result[1] == "-")
                {
                    if (result.Length < 4)
                    {
                        int bast = Convert.ToInt32(result[2]);
                        string first = Convert.ToString(bast);
                        string[] retu = { "-", result[0], first };
                        ret = retu;
                    }
                    else
                    {
                        MessageBox.Show("A Variable can contain just a value");
                        string[] rest = { "1", "1" };
                        ret = rest;//returning the value if its wrong
                    }
                }

                else if (result[0] == "if")
                {
                    if (result[2] == "==")
                    {
                        if (result[4] == "then")
                        {
                            int al = Convert.ToInt32(result[3]);
                            string first = Convert.ToString(al);
                            string second = Convert.ToString(k);
                            string[] retu = { "==", second, first, result[5], result[6], result[7], "then" };
                            ret = retu;
                        }
                        else
                        {
                            MessageBox.Show("You Did the Wrong Indeptetion");
                            string[] rest = { "1", "1" };
                            ret = rest;
                        }
                    }
                    else if(result[2]=="<=")
                    {
                        if (result[4] == "then")
                        {
                            int al = Convert.ToInt32(result[3]);
                            string first = Convert.ToString(al);
                            string second = Convert.ToString(k);
                            string[] retu = { "<=", second, first, result[5], result[6], result[7], "then" };
                            ret = retu;
                        }
                        else
                        {
                            MessageBox.Show("You Did the Wrong Indeptetion");
                            string[] rest = { "1", "1" };
                            ret = rest;
                        }
                    }
                    else if (result[2] == ">=")
                    {
                        if (result[4] == "then")
                        {
                            int al = Convert.ToInt32(result[3]);
                            string first = Convert.ToString(al);
                            string second = Convert.ToString(k);
                            string[] retu = { ">=", second, first, result[5], result[6], result[7], "then" };
                            ret = retu;
                        }
                        else
                        {
                            MessageBox.Show("You Did the Wrong Indeptetion");
                            string[] rest = { "1", "1" };
                            ret = rest;
                        }
                    }
                }
              



                else
                {
                    MessageBox.Show("Command Not Found");
                    string[] rest = { "1", "1" };
                    ret = rest;//returning the value if command not found

                }




                }


                catch (IndexOutOfRangeException e)//cathing index out of bound exception
                {
                    string[] rest = { "0", "0" };
                    ret = rest;
                }
                catch (FormatException e)//catching format type exception
                {
                    string[] rest = { "0", "0" };
                    ret = rest;
                }
                return ret;



            }

        }
       


    }

