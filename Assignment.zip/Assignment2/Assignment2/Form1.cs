﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2
{
    /// <summary>
    /// The main class which is controrlling all the component of this program
    /// </summary>
    public partial class Form1 : Form
    {
        Graphics g;//making graphichs to draw in panel
        int k = 0, l = 0;
        bool rek;
        public static Dictionary<String, Int32> Integer = new Dictionary<string, int>();
        string met;
        string met2;
        string pa;
        /// <summary>
        /// the method that control all the gui of this program
        /// </summary>
        public Form1()
        {
            InitializeComponent();//controls gui
            g = panel1.CreateGraphics();//controls the gui of panel

        }


        /// <summary>
        /// this clears the panel and reset the point to intial point of 0,0
        /// </summary>
        /// <param name="sender">Does not take any parameter</param>
        /// <param name="e">Its saves the intial value and return as event for further process</param>
        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Refresh();
            k = 0;
            l = 0;
            richTextBox1.Clear();
        }

        /// <summary>
        /// this reset the point to initial point of 0,0
        /// </summary>
        /// <param name="sender">Does not take any parameter</param>
        /// <param name="e">it saves the initial value and return as event for further process</param>

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDial = new OpenFileDialog();
            openDial.Title = "Browse The File";
            openDial.Filter = "Text Files(*.text)|*.txt|All Files(*.*)|*.*";
            if (openDial.ShowDialog() == DialogResult.OK)
            {
                StreamReader openStream = new StreamReader(File.OpenRead(openDial.FileName));
                richTextBox1.Text = openStream.ReadToEnd();
                openStream.Dispose();
            }
        }
        /// <summary>
        /// This is actually the multi line command which is used to execute the multiple command at a
        /// time it grabs the value from rich text and validate it and using shape factory it helps to draw
        /// shapes in panel
        /// Here i have also defined method
        /// Here i have also defined the loop
        /// here i have also defined the parameter method
        /// here i am sending the shapes in shape factory to make shapes
        /// I  have also added the polygon as new shapes
        /// Here i am playing with variables too
        /// </summary>
        /// <param name="sender">it take richtext text as a command </param>
        /// <param name="e">and draw the shapes in panel</param>

        private void button2_Click(object sender, EventArgs e)
        {
            string[] multiple = richTextBox1.Text.Split('\n');
            int i= 0;
            int j = 0;
            int t = 0;
            int t2 = 0;
            int t4 = 0;
            int looping = 0;
            bool first = false;
            bool second = false;
            bool four = false;
            bool fifth = false;
            bool six = false;
            bool seven = false;
            bool eight = false;
            bool nine = false;
            StringBuilder lop = new StringBuilder();
            StringBuilder sb = new StringBuilder();
            StringBuilder meth1 = new StringBuilder();
            StringBuilder meth2 = new StringBuilder();
            foreach (string line in multiple)
            {

                string[] forIf = line.Split(' ', ',');
                if ((line == "") || (line == " ") || (line == null))
                {
                }
                else if ((forIf[0].ToUpper() == "IF") && (forIf[4] == ":"))
                {
                    try
                    {
                        first = true;
                        if (Integer.ContainsKey(forIf[1]) == true)
                        {
                            string a = forIf[2];
                            int value = Integer[forIf[1]];
                            int value2 = Convert.ToInt32(forIf[3]);
                            if (a == "==")
                            {
                                if (value == value2)
                                {
                                    second = true;
                                }
                            }
                            else if (a == "<=")
                            {
                                if (value <= value2)
                                {
                                    second = true;
                                }
                            }
                            else if (a == ">=")
                            {
                                if (value >= value2)
                                {
                                    second = true;
                                }
                            }
                        }

                        continue;
                    }
                    catch (FormatException k)
                    {
                        MessageBox.Show("The Seond value of if should be integer");
                    }

                } 
                else if (forIf[0].ToUpper() == "ENDIF")
                {
                    first = false;
                    if (second)
                    {
                        string[] ak = sb.ToString().Split('\n');
                        foreach (string line2 in ak)
                        {
                            if (line2 == "" || line2 == " " || line2 == null)
                            {

                            }
                            else
                            {
                                Validate v2 = new Validate();
                                string[] res2 = v2.RetValue(line2);
                                t = t + 1;
                                try
                                {
                                    if (res2[0] == "0")
                                    {
                                        MessageBox.Show("if statement Parameter Missed Matched on line:" + t);
                                        break;
                                    }
                                    else if ((res2[0] == "1"))
                                    {
                                        MessageBox.Show("if statement Command Voilated on line:" + t);
                                        break;
                                    }
                                    else if (res2[0] == "moveTo")
                                    {
                                        int x = Convert.ToInt32(res2[1]);
                                        int y = Convert.ToInt32(res2[2]);
                                        k = x;
                                        l = y;
                                    }
                                    else if (res2[0] == "drawTo")
                                    {
                                        int x = Convert.ToInt32(res2[1]);
                                        int y = Convert.ToInt32(res2[2]);
                                        Pen p = new Pen(Color.Red, 4);
                                        g.DrawLine(p, new Point(k, l), new Point(x, y));
                                    }
                                    else if (res2[0] == "circle")
                                    {
                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("circle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "rectangle")
                                    {
                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("rectangle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "triangle")
                                    {

                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("triangle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "polygon")
                                    {

                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("polygon");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "=")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        string ab = res2[1];
                                        Integer.Add(ab, ink);
                                    }
                                    else if (res2[0] == "+")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        int k = Integer[res2[1]];
                                        Integer[res2[1]] = k + ink;
                                        int gk = Integer[res2[1]];
                                        string ab = Convert.ToString(gk);
                                    }
                                    else if (res2[0] == "-")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        int k = Integer[res2[1]];
                                        Integer[res2[1]] = k - ink;
                                        int gk = Integer[res2[1]];
                                        string ab = Convert.ToString(gk);
                                    }

                                    else if (res2[0] == "==")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }
                                    else if (res2[0] == "<=")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }
                                    else if (res2[0] == ">=")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }

                                }
                                catch (IndexOutOfRangeException kj)
                                {
                                    String whichLine = Convert.ToString(t);
                                    MessageBox.Show("Line:" + whichLine + " is incorrect inside if statement");
                                }
                                catch (ArgumentException kt)
                                {

                                }

                            }
                        }
                        second = false;
                    }
                    else
                    {
                        MessageBox.Show("The if statment is incorrect");
                    }
                    continue;
                }
                else if (forIf[0].ToUpper() == "LOOP" && forIf[1].ToUpper() == "FOR")
                {
                    four = true;
                    try
                    {
                        if (Integer.ContainsKey(forIf[2]) == true)
                        {
                            looping = Integer[forIf[2]];
                            fifth = true;
                        }
                    }
                    catch (FormatException k)
                    {
                        MessageBox.Show("The value of loop should be integer");
                    }
                    continue;
                }
                else if (forIf[0].ToUpper() == "ENDLOOP")
                {
                    four = false;
                    if (fifth)
                    {
                        string[] ak2 = lop.ToString().Split('\n');
                        for (int kt = 1; kt <= looping; kt++)
                        {
                            foreach (string line4 in ak2)
                            {
                                if (line4 == "" || line4 == " " || line4 == null)
                                {
                                }
                                else
                                {

                                    Validate v2 = new Validate();
                                    string[] res2 = v2.RetValue(line4);
                                    t2 = t2 + 1;
                                    try
                                    {
                                        if (res2[0] == "0")
                                        {
                                            MessageBox.Show("loop statement Parameter Missed Matched on line:" + t2);
                                            break;
                                        }
                                        else if ((res2[0] == "1"))
                                        {
                                            MessageBox.Show("loop statement Command Voilated on line:" + t2);
                                            break;
                                        }
                                        else if (res2[0] == "moveTo")
                                        {
                                            int x = Convert.ToInt32(res2[1]);
                                            int y = Convert.ToInt32(res2[2]);
                                            k = x;
                                            l = y;
                                        }
                                        else if (res2[0] == "drawTo")
                                        {
                                            int x = Convert.ToInt32(res2[1]);
                                            int y = Convert.ToInt32(res2[2]);
                                            Pen p = new Pen(Color.Red, 4);
                                            g.DrawLine(p, new Point(k, l), new Point(x, y));
                                        }
                                        else if (res2[0] == "circle")
                                        {
                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("circle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "rectangle")
                                        {
                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("rectangle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "triangle")
                                        {

                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("triangle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "polygon")
                                        {

                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("polygon");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "=")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            string ab = res2[1];
                                            Integer.Add(ab, ink);
                                        }
                                        else if (res2[0] == "+")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            int k = Integer[res2[1]];
                                            Integer[res2[1]] = k + ink;
                                            int gk = Integer[res2[1]];
                                            string ab = Convert.ToString(gk);
                                        }
                                        else if (res2[0] == "-")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            int k = Integer[res2[1]];
                                            Integer[res2[1]] = k - ink;
                                            int gk = Integer[res2[1]];
                                            string ab = Convert.ToString(gk);
                                        }

                                        else if (res2[0] == "==")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }
                                        else if (res2[0] == "<=")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }
                                        else if (res2[0] == ">=")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }

                                    }
                                    catch (IndexOutOfRangeException kj)
                                    {
                                        String whichLine = Convert.ToString(t);
                                        MessageBox.Show("Line:" + whichLine + " is incorrect inside loop statement");
                                    }
                                    catch (ArgumentException kt2)
                                    {

                                    }

                                }
                            }
                        }
                        fifth = false;
                    }
                    else
                    {
                        MessageBox.Show("Looping Statemnet is Incorrect");
                    }
                    continue;

                }
                else if(forIf[0].ToUpper()=="METHOD" && forIf[2]=="()")
                {
                    six = true;
                    if(Integer.ContainsKey(forIf[1])==false)
                    {
                        seven = true;
                        met = forIf[1].ToUpper();
                    }
                    continue;
                }
                else if(forIf[0].ToUpper()=="ENDMETHOD")
                {
                    six = false;
                    if(seven)
                    {}
                    else
                    {
                        MessageBox.Show("Your Method is Indepdented Wrong");
                    }
                    continue;
                }
                else if((forIf[0].ToUpper() == met)&&(forIf[1]=="()"))
                {
                    if(seven)
                    {
                        string[] ak4 = meth1.ToString().Split('\n');
                        foreach (string line2 in ak4)
                        {

                            if (line2 == "" || line2 == " " || line2 == null)
                            {

                            }
                            else
                            {
                                Validate v2 = new Validate();
                                string[] res2 = v2.RetValue(line2);
                                t4 = t4 + 1;
                                try
                                {
                                    if (res2[0] == "0")
                                    {
                                        MessageBox.Show("Method Parameter Missed Matched on line:" + t4);
                                        break;
                                    }
                                    else if ((res2[0] == "1"))
                                    {
                                        MessageBox.Show("method Command Voilated on line:" + t4);
                                        break;
                                    }
                                    else if (res2[0] == "moveTo")
                                    {
                                        int x = Convert.ToInt32(res2[1]);
                                        int y = Convert.ToInt32(res2[2]);
                                        k = x;
                                        l = y;
                                    }
                                    else if (res2[0] == "drawTo")
                                    {
                                        int x = Convert.ToInt32(res2[1]);
                                        int y = Convert.ToInt32(res2[2]);
                                        Pen p = new Pen(Color.Red, 4);
                                        g.DrawLine(p, new Point(k, l), new Point(x, y));
                                    }
                                    else if (res2[0] == "circle")
                                    {
                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("circle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "rectangle")
                                    {
                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("rectangle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "triangle")
                                    {

                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("triangle");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "polygon")
                                    {

                                        ShapeFactory shapeFactory = new ShapeFactory();
                                        Shape shape1 = shapeFactory.getShape("polygon");
                                        shape1.drawdesign(res2, g, k, l);
                                    }
                                    else if (res2[0] == "=")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        string ab = res2[1];
                                        Integer.Add(ab, ink);
                                    }
                                    else if (res2[0] == "+")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        int k = Integer[res2[1]];
                                        Integer[res2[1]] = k + ink;
                                        int gk = Integer[res2[1]];
                                        string ab = Convert.ToString(gk);
                                    }
                                    else if (res2[0] == "-")
                                    {
                                        int ink = Convert.ToInt32(res2[2]);
                                        int k = Integer[res2[1]];
                                        Integer[res2[1]] = k - ink;
                                        int gk = Integer[res2[1]];
                                        string ab = Convert.ToString(gk);
                                    }

                                    else if (res2[0] == "==")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }
                                    else if (res2[0] == "<=")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }
                                    else if (res2[0] == ">=")
                                    {
                                        if (res2[6] == "then")
                                        {
                                            Form1 frm = new Form1();
                                            string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                            frm.single(rek);
                                        }
                                    }

                                }
                                catch (IndexOutOfRangeException kj)
                                {
                                    String whichLine = Convert.ToString(t);
                                    MessageBox.Show("Line:" + whichLine + " is incorrect inside method");
                                }
                                catch (ArgumentException kt)
                                {

                                }

                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("You cannot Execute this method");
                    }
                    seven = false;
                    continue;
                }
                
                else if(forIf[0].ToUpper()=="METHOD" && forIf[2]=="(" && forIf[4]==")" )
                {
                    eight = true;
                    if(Integer.ContainsKey(forIf[1])==false)
                    {
                        if(Integer.ContainsKey(forIf[3])==false)
                        {
                            nine = true;
                            met2 = forIf[1].ToUpper();
                            pa = forIf[3];
                        }
                        
                    }
                    continue;
                }
                else if(forIf[0].ToUpper()=="ENDPARAMETHOD")
                {
                    eight = false;
                    if(nine)
                    { }
                    else { MessageBox.Show("Your Parameter Method is wrong"); }
                    continue;
                }
                else if(forIf[0].ToUpper()==met2 && forIf[1]=="(" && forIf[3]==")")
                {
                    if(nine)
                    {
                        if(Integer.ContainsKey(forIf[2])==true)
                        {
                            int a = Integer[forIf[2]];
                            Integer.Add(pa, a);
                            string[] ak4 = meth2.ToString().Split('\n');

                            foreach (string line2 in ak4)
                            {

                                if (line2 == "" || line2 == " " || line2 == null)
                                {

                                }
                                else
                                {
                                    Validate v2 = new Validate();
                                    string[] res2 = v2.RetValue(line2);
                                    t4 = t4 + 1;
                                    try
                                    {
                                        if (res2[0] == "0")
                                        {
                                            MessageBox.Show("Method Parameter Missed Matched on line:" + t4);
                                            break;
                                        }
                                        else if ((res2[0] == "1"))
                                        {
                                            MessageBox.Show("method Command Voilated on line:" + t4);
                                            break;
                                        }
                                        else if (res2[0] == "moveTo")
                                        {
                                            int x = Convert.ToInt32(res2[1]);
                                            int y = Convert.ToInt32(res2[2]);
                                            k = x;
                                            l = y;
                                        }
                                        else if (res2[0] == "drawTo")
                                        {
                                            int x = Convert.ToInt32(res2[1]);
                                            int y = Convert.ToInt32(res2[2]);
                                            Pen p = new Pen(Color.Red, 4);
                                            g.DrawLine(p, new Point(k, l), new Point(x, y));
                                        }
                                        else if (res2[0] == "circle")
                                        {
                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("circle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "rectangle")
                                        {
                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("rectangle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "triangle")
                                        {

                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("triangle");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "polygon")
                                        {

                                            ShapeFactory shapeFactory = new ShapeFactory();
                                            Shape shape1 = shapeFactory.getShape("polygon");
                                            shape1.drawdesign(res2, g, k, l);
                                        }
                                        else if (res2[0] == "=")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            string ab = res2[1];
                                            Integer.Add(ab, ink);
                                        }
                                        else if (res2[0] == "+")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            int k = Integer[res2[1]];
                                            Integer[res2[1]] = k + ink;
                                            int gk = Integer[res2[1]];
                                            string ab = Convert.ToString(gk);
                                        }
                                        else if (res2[0] == "-")
                                        {
                                            int ink = Convert.ToInt32(res2[2]);
                                            int k = Integer[res2[1]];
                                            Integer[res2[1]] = k - ink;
                                            int gk = Integer[res2[1]];
                                            string ab = Convert.ToString(gk);
                                        }

                                        else if (res2[0] == "==")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }
                                        else if (res2[0] == "<=")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }
                                        else if (res2[0] == ">=")
                                        {
                                            if (res2[6] == "then")
                                            {
                                                Form1 frm = new Form1();
                                                string[] rek = { res2[0], res2[1], res2[2], res2[3], res2[4], res2[5] };
                                                frm.single(rek);
                                            }
                                        }

                                    }
                                    catch (IndexOutOfRangeException kj)
                                    {
                                        String whichLine = Convert.ToString(t);
                                        MessageBox.Show("Line:" + whichLine + " is incorrect inside method");
                                    }
                                    catch (ArgumentException kt)
                                    {

                                    }

                                }

                            }

                        }
                        else { MessageBox.Show("You Have Defined the param"); }
                    }
                    else { MessageBox.Show("You Cannot Evoke the Method"); }
                }
               
                
                
                
                
                else
                {

                    if (first)
                    {
                        sb.Append(line + "\n");
                    }
                    else if (four)
                    {
                        lop.Append(line + "\n");
                    }
                    else if(six)
                    {
                        meth1.Append(line + "\n");
                    }
                    else if(eight)
                    {
                        meth2.Append(line + "\n");
                    }
                    else
                    {
                        Validate v = new Validate();
                        string[] res = v.RetValue(line);
                        i = i + 1;

                        try
                        {
                            if (res[0] == "0")
                            {
                                MessageBox.Show("Parameter Missed Matched on line:" + i);
                                break;
                            }
                            else if ((res[0] == "1"))
                            {
                                MessageBox.Show("Command Voilated on line:" + i);
                                break;
                            }
                            else if (res[0] == "moveTo")
                            {
                                int x = Convert.ToInt32(res[1]);
                                int y = Convert.ToInt32(res[2]);
                                k = x;
                                l = y;
                            }
                            else if (res[0] == "drawTo")
                            {
                                int x = Convert.ToInt32(res[1]);
                                int y = Convert.ToInt32(res[2]);
                                Pen p = new Pen(Color.Red, 4);
                                g.DrawLine(p, new Point(k, l), new Point(x, y));
                            }
                            else if (res[0] == "circle")
                            {
                                ShapeFactory shapeFactory = new ShapeFactory();
                                Shape shape1 = shapeFactory.getShape("circle");
                                shape1.drawdesign(res, g, k, l);
                            }
                            else if (res[0] == "rectangle")
                            {
                                ShapeFactory shapeFactory = new ShapeFactory();
                                Shape shape1 = shapeFactory.getShape("rectangle");
                                shape1.drawdesign(res, g, k, l);
                            }
                            else if (res[0] == "triangle")
                            {

                                ShapeFactory shapeFactory = new ShapeFactory();
                                Shape shape1 = shapeFactory.getShape("triangle");
                                shape1.drawdesign(res, g, k, l);
                            }
                            else if (res[0] == "polygon")
                            {

                                ShapeFactory shapeFactory = new ShapeFactory();
                                Shape shape1 = shapeFactory.getShape("polygon");
                                shape1.drawdesign(res, g, k, l);
                            }
                            else if (res[0] == "=")
                            {
                                int ink = Convert.ToInt32(res[2]);
                                string ab = res[1];
                                Integer.Add(ab, ink);
                            }
                            else if (res[0] == "+")
                            {
                                int ink = Convert.ToInt32(res[2]);
                                int k = Integer[res[1]];
                                Integer[res[1]] = k + ink;
                                int gk = Integer[res[1]];
                                string ab = Convert.ToString(gk);
                            }
                            else if (res[0] == "-")
                            {
                                int ink = Convert.ToInt32(res[2]);
                                int k = Integer[res[1]];
                                Integer[res[1]] = k - ink;
                                int gk = Integer[res[1]];
                                string ab = Convert.ToString(gk);
                            }

                            else if (res[0] == "==")
                            {
                                if (res[6] == "then")
                                {
                                    Form1 frm = new Form1();
                                    string[] rek = { res[0], res[1], res[2], res[3], res[4], res[5] };
                                    frm.single(rek);
                                }
                            }
                            else if (res[0] == "<=")
                            {
                                if (res[6] == "then")
                                {
                                    Form1 frm = new Form1();
                                    string[] rek = { res[0], res[1], res[2], res[3], res[4], res[5] };
                                    frm.single(rek);
                                }
                            }
                            else if (res[0] == ">=")
                            {
                                if (res[6] == "then")
                                {
                                    Form1 frm = new Form1();
                                    string[] rek = { res[0], res[1], res[2], res[3], res[4], res[5] };
                                    frm.single(rek);
                                }
                            }

                        }
                        catch (IndexOutOfRangeException kj)
                        {
                            String whichLine = Convert.ToString(i);
                            MessageBox.Show("Line:" + whichLine + " is incorrect");
                        }
                        catch (ArgumentException kt)
                        {

                        }

                    }
                }
                 

                j = j + 1;

            }
        }
        /// <summary>
        /// It helps to save the text from richtext 
        /// </summary>
        /// <param name="sender">take parameter from richtext to execte</param>
        /// <param name="e">saves the value in a textfile1.txt file</param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDial = new SaveFileDialog();
            saveDial.Title = "Save The File";
            saveDial.Filter = "Text Files(*.text)|*.txt|All Files(*.*)|*.*";
            if (saveDial.ShowDialog() == DialogResult.OK)
            {
                StreamWriter savestream = new StreamWriter(File.Create(saveDial.FileName));
                savestream.Write(richTextBox1.Text);
                savestream.Dispose();
            }
            MessageBox.Show("Saved");
        }

        /// <summary>
        /// This help to retrive the commands from textfile1.txt and present in richtextbox1
        /// </summary>
        /// <param name="sender">its take textfile1.txt commands as parameter</param>
        /// <param name="e">and display commands on rich text box</param>

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {

            OpenFileDialog openDial = new OpenFileDialog();
            openDial.Title = "Browse The File";
            openDial.Filter = "Text Files(*.text)|*.txt|All Files(*.*)|*.*";
            if (openDial.ShowDialog() == DialogResult.OK)
            {
                StreamReader openStream = new StreamReader(File.OpenRead(openDial.FileName));
                richTextBox1.Text = openStream.ReadToEnd();
                openStream.Dispose();
            }


        }
        /// <summary>
        /// This help to create the shortcut keys
        /// </summary>
        /// <param name="sender">Take key stroke as parameter</param>
        /// <param name="e">perform the task taking keystroke as command</param>
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
         
            if (e.Control == true && e.KeyCode == Keys.C)
            {
                button3.PerformClick();
            }
            if (e.Control == true && e.KeyCode == Keys.F)
            {
                button2.PerformClick();
            }
            if (e.Control == true && e.KeyCode == Keys.T)
            {
                button4.PerformClick();
            }
        }
        /// <summary>
        /// just assigning the keystroke permission 
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }
        /// <summary>
        /// makings a list of keystroke commands
        /// </summary>
        private void keyStrokesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("CTRL + R=Run" + "\n" + "CTRL + C=Clear" + '\n' +
                "CTRL + F=Execute" + '\n' + "CTRL + T=Reset", "KeyStrokes");
        }

        /// <summary>
        /// making the list of commands
        /// </summary>
        private void commandsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("moveto parm,parm" + "\n" + "drawto parm,param" + '\n' +
                "cirle param" + '\n' + "rectangle parm,parm" + '\n' + "triangle parm,parm,parm", "Commands");
        }

        /// <summary>
        /// this help to shutdown the whole program 
        /// </summary>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        /// <summary>
        /// This is actually the single line command which is used to execute the single command at a
        /// time it grabs the value from textbox and validate it and using shape factory it helps to draw
        /// shapes in panel
        /// </summary>
        /// <param name="sender">it take textbox text as a command </param>
        /// <param name="e">and draw the shapes in panel</param>

        private void button1_Click(object sender, EventArgs e)
        {



        
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveDial = new SaveFileDialog();
            saveDial.Title = "Save The File";
            saveDial.Filter = "Text Files(*.text)|*.txt|All Files(*.*)|*.*";
            if (saveDial.ShowDialog() == DialogResult.OK)
            {
                StreamWriter savestream = new StreamWriter(File.Create(saveDial.FileName));
                savestream.Write(richTextBox1.Text);
                savestream.Dispose();
            }
            MessageBox.Show("Saved");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Program Is Developed By Sujan Karki ");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Here i have made the method for single if statement
        /// Here I have defined the single if statment so that we can call the If in between
        /// </summary>
        /// <param name="res"></param>

        public void single(string[] res)
        {
            int a = Convert.ToInt32(res[1]);
            int b = Convert.ToInt32(res[2]);
            if(res[0]=="==")
            {
                if (a == b)
                {
                    if (Integer.ContainsKey(res[3]))
                    {
                        if (res[4] == "+")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k + ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                        else if (res[4] == "-")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k - ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Value Not Assinged");
                    }
                }
            }


            else if (res[0] == "<=")
            {
                if (a <= b)
                {
                    if (Integer.ContainsKey(res[3]))
                    {
                        if (res[4] == "+")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k + ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                        else if (res[4] == "-")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k - ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Value Not Assinged");
                    }

                }
            }
            else if (res[0] == ">=")
            {
                if (a >= b)
                {
                    if (Integer.ContainsKey(res[3]))
                    {
                        if (res[4] == "+")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k + ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                        else if (res[4] == "-")
                        {
                            int ink = Convert.ToInt32(res[5]);
                            int k = Integer[res[3]];
                            Integer[res[3]] = k - ink;
                            int gk = Integer[res[3]];
                            string ab = Convert.ToString(gk);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Value Not Assinged");
                    }
                }
            }





        }
    



    }
}
