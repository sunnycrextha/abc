﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
           // Assignment2.Validate ob = new Assignment2.Validate();
            //string command = "circle a";
           // string[] k = ob.RetValue(command);
           // string[] match = {"0","0"};
           // CollectionAssert.AreEqual(match, k);
        }
    }
}
